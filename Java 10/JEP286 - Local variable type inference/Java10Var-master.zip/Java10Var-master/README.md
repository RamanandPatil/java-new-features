# New Java 10 Language Feature: Local-Variable Type Inference (var)!
Java source code example demonstrating Local variable Type Inference (var), posted on personal blog (http://bit.ly/VarJava).
Built and tested  with the Azul System's Zulu JDK on Fedora Linux, SUSE Linux.

![alt text](https://raw.githubusercontent.com/afinlay5/Java10Var/master/blog.png)

# Platform 
- Any supporting a JVM for Java SE 10+.

# Requirements
- Java 10 or greater

# Known Problems
- None (04/30/2018).

# Execution Screenshot
![alt text](https://raw.githubusercontent.com/afinlay5/Java10Var/master/run.png)